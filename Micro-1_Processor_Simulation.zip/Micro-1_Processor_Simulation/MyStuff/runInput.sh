#! /bin/bash
printf "...Running Code...\n"
# cd Micro-1_Processor_Simulation/
javac Memory.java
javac Processor.java
javac Console.java
for i in /Users/brianaranda/Desktop/College\ Courses/Spring\ 2019/Computer\ Organization/Project/-Micro-1-Processor-Simulation/Micro-1\ Processor\ Simulation/InputFile/*.in; do
    printf "RUNNING $i\n\n\n"
   [ -f "$i" ] || break
    java Console < "$i"
done
